package it.polito.dp2.BIB.sol3.service;


public enum SearchScope {
	ALL,
	ARTICLES,
	BOOKS;
}
